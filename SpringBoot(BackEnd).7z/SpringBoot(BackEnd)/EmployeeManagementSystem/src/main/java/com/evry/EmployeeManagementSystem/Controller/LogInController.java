package com.evry.EmployeeManagementSystem.Controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.evry.EmployeeManagementSystem.Model.Login;
import com.evry.EmployeeManagementSystem.Service.LoginService;

@RestController
@CrossOrigin(origins = "*", allowedHeaders = "*")
@RequestMapping("/login")
public class LogInController {
	
	@Autowired
	LoginService loginService;
	
	@PostMapping("/verify")
	public boolean verifyLoginCredentials(@RequestBody Login loginCredentials) {
		return loginService.verifyLoginCredentials(loginCredentials);
		
	}

}
