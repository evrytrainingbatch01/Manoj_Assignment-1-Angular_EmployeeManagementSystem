package com.evry.EmployeeManagementSystem.Model;

import java.util.List;

public class SelectedEmployeeIds {
	
	private List<Integer> ids;
	

	public SelectedEmployeeIds(List<Integer> ids) {
		super();
		this.ids = ids;
	}

	public SelectedEmployeeIds() {
		super();
	}

	public List<Integer> getIds() {
		return ids;
	}

	public void setIds(List<Integer> ids) {
		this.ids = ids;
	}

	@Override
	public String toString() {
		return "SelectedEmployeeIds [ids=" + ids + "]";
	}
	

}
