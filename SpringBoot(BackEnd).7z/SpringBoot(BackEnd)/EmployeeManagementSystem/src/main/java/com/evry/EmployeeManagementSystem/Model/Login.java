package com.evry.EmployeeManagementSystem.Model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.UniqueConstraint;

@Entity
@Table(name="Login",uniqueConstraints=@UniqueConstraint(columnNames="loginName"))
public class Login {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="loginId")
	private int  loginId ;
	
	@Column(name="loginName")
	private String  loginName ;
	
	@Column(name="password")
	private String 	password;
	
	public Login() {
		super();
	}

	public Login(int loginId, String loginName, String password) {
		super();
		this.loginId = loginId;
		this.loginName = loginName;
		this.password = password;
	}

	public int getLoginId() {
		return loginId;
	}

	public void setLoginId(int loginId) {
		this.loginId = loginId;
	}

	public String getLoginName() {
		return loginName;
	}

	public void setLoginName(String loginName) {
		this.loginName = loginName;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	@Override
	public String toString() {
		return "Login [loginId=" + loginId + ", loginName=" + loginName + ", password=" + password + "]";
	}
	
	


	
	
	

}
