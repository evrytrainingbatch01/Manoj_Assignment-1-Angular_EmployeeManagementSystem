package com.evry.EmployeeManagementSystem.Model;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "EMPLOYEE")
public class Employee {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="employeeId")
	private int  id;
	
	@Column(name="employeeFirstName")
	private String firstName;
	
	@Column(name="employeeLastName")
	private String lastName;
	
	@Column(name="employeeDateOfBirth")
	private Date dateOfBirth;
	
	@Column(name="employeeEmail")
	private String email;
	
	@Column(name="employeePhone")
	private String phone;
	
	@Column(name="employeeAddress")
	private String address;
	
	@Column(name="employeeCountry")
	private String country;
	
	@Column(name="employeeType")
	private String type;
	
	@Column(name="employeeTechnicalSkills")
	private String skills;
	
	public Employee() {
		super();
	}

	public Employee(int id, String firstName, String lastName, Date dateOfBirth, String email, String phone,
			String address, String country, String type, String skills) {
		super();
		this.id = id;
		this.firstName = firstName;
		this.lastName = lastName;
		this.dateOfBirth = dateOfBirth;
		this.email = email;
		this.phone = phone;
		this.address = address;
		this.country = country;
		this.type = type;
		this.skills = skills;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public Date getDateOfBirth() {
		return dateOfBirth;
	}

	public void setDateOfBirth(Date dateOfBirth) {
		this.dateOfBirth = dateOfBirth;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getPhone() {
		return phone;
	}

	public void setPhone(String phone) {
		this.phone = phone;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getCountry() {
		return country;
	}

	public void setCountry(String country) {
		this.country = country;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public String getSkills() {
		return skills;
	}

	public void setSkills(String skills) {
		this.skills = skills;
	}

	@Override
	public String toString() {
		return "Employee [id=" + id + ", firstName=" + firstName + ", lastName=" + lastName + ", dateOfBirth="
				+ dateOfBirth + ", email=" + email + ", phone=" + phone + ", address=" + address + ", country="
				+ country + ", type=" + type + ", skills=" + skills + "]";
	}


	
	

}
