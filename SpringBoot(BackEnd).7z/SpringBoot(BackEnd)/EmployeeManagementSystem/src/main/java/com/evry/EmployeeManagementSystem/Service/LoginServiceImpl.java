package com.evry.EmployeeManagementSystem.Service;

import java.util.Collection;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.evry.EmployeeManagementSystem.Dao.LogInDao;
import com.evry.EmployeeManagementSystem.Model.Login;

@Service
public class LoginServiceImpl implements LoginService{
	
	@Autowired
	LogInDao loginDao;

	@Override
	public boolean verifyLoginCredentials(Login loginCredentials) {
		
		boolean isEmployeeExits=false;
		
		Collection<Login> presentEmployee=findLoginEmailId((String)loginCredentials.getLoginName().toString());
		if(presentEmployee.isEmpty()) {
			isEmployeeExits=false;
		}else {
			System.out.println("presentEmployee"+presentEmployee);
			for (Login login : presentEmployee) {
				if(login.getLoginName().equals(loginCredentials.getLoginName()) && login.getPassword().equals(loginCredentials.getPassword())) {
						 
						  isEmployeeExits=true; 
				}
				
			}

			
		}
		return isEmployeeExits;
	}

	@Override
	public Collection<Login> findLoginEmailId(String emailid) {
		return loginDao.findLoginEmailId(emailid);
		
	}

}
