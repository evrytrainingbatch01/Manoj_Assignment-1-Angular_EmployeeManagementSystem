package com.evry.EmployeeManagementSystem.Service;

import java.util.List;
import java.util.Optional;

import org.springframework.stereotype.Service;

import com.evry.EmployeeManagementSystem.Model.Employee;
import com.evry.EmployeeManagementSystem.Model.SelectedEmployeeIds;

@Service
public interface EmployeeService {
	
	public Employee addEmployee(Employee employee);
	
	public List<Employee> getAllEmployees();
	
	public Optional<Employee> getEmployeeById(int id);
	
	public Employee updateEmployee(Employee employee);
	
	public boolean deleteEmployee(int id);

	public boolean deleteAllEmployees();

	public boolean deleteSelectedEmployee(SelectedEmployeeIds ids);

}
