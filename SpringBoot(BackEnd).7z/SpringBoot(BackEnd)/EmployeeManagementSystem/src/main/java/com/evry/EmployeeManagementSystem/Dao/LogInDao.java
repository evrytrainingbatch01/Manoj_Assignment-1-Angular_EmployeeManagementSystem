package com.evry.EmployeeManagementSystem.Dao;

import java.util.Collection;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.evry.EmployeeManagementSystem.Model.Login;

@Repository
public class LogInDao {
	
	@Autowired
	public LoginRepository loginRepository;
	
	public Collection<Login> findLoginEmailId(String emailId){
		
		return loginRepository.findLoginEmailId(emailId);
		
	}
	

}
