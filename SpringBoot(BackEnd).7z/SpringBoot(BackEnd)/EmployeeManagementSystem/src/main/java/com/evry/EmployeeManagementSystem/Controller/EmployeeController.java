package com.evry.EmployeeManagementSystem.Controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.evry.EmployeeManagementSystem.Model.Employee;
import com.evry.EmployeeManagementSystem.Model.SelectedEmployeeIds;
import com.evry.EmployeeManagementSystem.Service.EmployeeService;

@RestController
//@RequestMapping("/employee")
@CrossOrigin(origins = "*", allowedHeaders = "*")
public class EmployeeController {
	
	@Autowired
	EmployeeService employeeService;
	
	@PostMapping(path ="/employee",produces = MediaType.APPLICATION_JSON_VALUE) 
	public Employee addEmployee(@RequestBody Employee employee) {
		System.out.println("employee - "+ employee);
		return employeeService.addEmployee(employee);
	}
	
	@GetMapping("/employee")
	public List<Employee> getAllEmployees(){
	
		return employeeService.getAllEmployees();
	}
	
	@GetMapping("/employee/{id}")
	public Optional<Employee> getEmployeeById(@PathVariable int id){
		return employeeService.getEmployeeById(id);
	}
	
	@PutMapping("/employee")
	public Employee updateEmployee(@RequestBody Employee employee) {
		return employeeService.updateEmployee(employee);
	}
	
	@DeleteMapping("/employee/{id}")
	public boolean deleteEmployee(@PathVariable int id) {
		return employeeService.deleteEmployee(id);
	}
	@DeleteMapping("/employee/deleteSelected")
	public boolean deleteSelectedEmployee(@RequestBody SelectedEmployeeIds ids) {
		return employeeService.deleteSelectedEmployee(ids);
	}
	
	@DeleteMapping("/employee/deleteAll")
	public boolean deleteAllEmployees() {
		return employeeService.deleteAllEmployees();
	}

}
