package com.evry.EmployeeManagementSystem.Service;

import java.util.Collection;

import org.springframework.stereotype.Service;

import com.evry.EmployeeManagementSystem.Model.Login;
@Service
public interface LoginService {
	
	public boolean verifyLoginCredentials(Login loginCredentials);
	
	public Collection<Login> findLoginEmailId(String emailid);

}
