package com.evry.EmployeeManagementSystem.Dao;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.evry.EmployeeManagementSystem.Model.Employee;
import com.evry.EmployeeManagementSystem.Model.SelectedEmployeeIds;

@Repository
public class EmployeeDao {

	@Autowired
	EmployeeRepository employeeRepository;
	
	public Employee addEmployee(Employee employee) {
		return employeeRepository.save(employee);
		
	}
	
	public List<Employee> getAllEmployees(){
		return employeeRepository.findAll();
	}
	
	public Optional<Employee> getEmployeeById(int id) {
		return employeeRepository.findById(id);
	}
	
	public Employee updateEmployee(Employee employee) {
		return employeeRepository.save(employee); 
	}
	
	public boolean deleteEmployee(int id) {
		boolean flag=false;
		try {
			
			employeeRepository.deleteById(id); 
			
			flag=true;
		}catch (Exception e) {
			e.printStackTrace();
			flag=false;
		}
		
		return flag;
	}
	public boolean deleteAllEmployees() {
		boolean flag=false;
		try {
			
			employeeRepository.deleteAll(); 
			
			flag=true;
		}catch (Exception e) {
			e.printStackTrace();
			flag=false;
		}
		
		return flag;
	}

	public boolean deleteSelectedEmployee(SelectedEmployeeIds ids) {
		boolean flag=false;
		ids.getIds().forEach(id ->employeeRepository.deleteById(id));
		 flag=true;
		// TODO Auto-generated method stub
		return flag;
	}
	
}
