package com.evry.EmployeeManagementSystem.Service;

import java.util.List;
import java.util.Optional;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.evry.EmployeeManagementSystem.Dao.EmployeeDao;
import com.evry.EmployeeManagementSystem.Model.Employee;
import com.evry.EmployeeManagementSystem.Model.SelectedEmployeeIds;

@Service
public class EmployeeServiceImpl implements EmployeeService{
	
	@Autowired
	EmployeeDao employeeDao;

	@Override
	@Transactional
	public Employee addEmployee(Employee employee) {

		return employeeDao.addEmployee(employee);
	}

	@Override
	@Transactional
	public List<Employee> getAllEmployees() {

		return employeeDao.getAllEmployees();
	}

	@Override
	@Transactional
	public Optional<Employee> getEmployeeById(int id) {
		return employeeDao.getEmployeeById(id);
	}

	@Override
	@Transactional
	public Employee updateEmployee(Employee employee) {

		return employeeDao.updateEmployee(employee);
	}

	@Override
	@Transactional
	public boolean deleteEmployee(int id) {
		return employeeDao.deleteEmployee(id);
	}
	@Override
	@Transactional
	public boolean deleteSelectedEmployee(SelectedEmployeeIds ids) {
		return employeeDao.deleteSelectedEmployee(ids);
	}
	
	@Override
	@Transactional
	public boolean deleteAllEmployees() {
		return employeeDao.deleteAllEmployees();
	}

}
